const createCsvWriter = require('csv-writer').createObjectCsvWriter;

module.exports = async function (path, data) {

    const csvWriter = createCsvWriter({
        path: path,
        header: [
            { id: 'username', title: 'Username' },
            { id: 'email', title: 'Email' },
        ],
        append: true,
        encoding: "utf8",
        fieldDelimiter: ";"
    });

    try {
        await csvWriter.writeRecords(data);
        console.log('CSV was created');
    } catch (err) {
        console.error('Error writing CSV:', err);
    }

}