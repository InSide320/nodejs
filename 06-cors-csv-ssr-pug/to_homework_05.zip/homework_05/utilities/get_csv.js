const fs = require("fs");
const {parse} = require("csv-parse");

module.exports = async function (path, params = {}) {
    const result = [];
    const parsingData = fs
                        .createReadStream(path)
                        .pipe(parse(params));
    for await (const row of parsingData) {
        result.push(row);
    }
    return result;
}